# -*- coding: utf-8 -*-
msg = {
        'ar': {
                'blockpageschecker-summary': u'بوت: حذف قالب قديم',
        },
        'en': {
                'blockpageschecker-summary': u'Bot: Deleting out-dated template',
        },
        'fr': {
                'blockpageschecker-summary': u'Robot: Mise à jour des bandeaux de protection',
        },
        'he': {
                'blockpageschecker-summary': u'בוט: מסיר תבנית שעבר זמנה',
        },
        'it': {
                'blockpageschecker-summary': u'Bot: Tolgo o sistemo template di avviso blocco',
        },
        'ja': {
                'blockpageschecker-summary': u'ロボットによる: 保護テンプレート除去',
        },
        'pt': {
                'blockpageschecker-summary': u'Bot: Retirando predefinição de proteção',
        },
        'qqq': {
                'blockpageschecker-summary': u'Edit summary for blockpageschecker report',
        },
        'zh': {
                'blockpageschecker-summary': u'機器人: 移除過期的保護模板',
        },
}
